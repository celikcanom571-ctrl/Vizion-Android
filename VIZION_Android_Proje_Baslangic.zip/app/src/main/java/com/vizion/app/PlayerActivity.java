package com.vizion.app;

import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends AppCompatActivity {
  private ExoPlayer player;
  private PlayerView view;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    String url = getIntent().getStringExtra("url");
    String title = getIntent().getStringExtra("title");
    if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) { finish(); return; }
    view = new PlayerView(this);
    view.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    view.setUseController(true);
    setContentView(view);
    setTitle(title == null ? "VIZION" : title);
    player = new ExoPlayer.Builder(this).build();
    view.setPlayer(player);
    player.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
    player.prepare();
    player.play();
  }
  @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
  @Override protected void onDestroy() { if (player != null) { player.release(); player = null; } super.onDestroy(); }
}
