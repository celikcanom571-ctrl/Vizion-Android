VIZION Android başlangıç projesi

İÇERİK
- Mevcut VIZION v1.1 HTML arayüzü assets/index.html içine alındı.
- Android WebView kabuğu hazırlandı.
- Yerel AndroidX Media3 ExoPlayer ekranı eklendi.
- HLS ve MP4 modülleri Gradle bağımlılıklarında tanımlandı.

ÖNEMLİ
Bu ZIP derlenmiş APK değildir; Android Studio/AndroidIDE ile derlenmesi gereken kaynak projedir.
Bu ilk iskelette HTML tarafındaki film detay düğmeleri henüz ExoPlayer'a bağlanmamıştır.
Bağlantı için JavaScript tarafında şu çağrı kullanılabilir:
window.VizionPlayer.play("https://izinli-ornek-video-adresi/video.m3u8", "Film adı");

Sadece yayınlama/izleme hakkına sahip olduğunuz doğrudan medya URL'lerini kullanın.
Nuvio sağlayıcı eklentilerinin JavaScript çalışma ortamı bu projeye dahil değildir.
